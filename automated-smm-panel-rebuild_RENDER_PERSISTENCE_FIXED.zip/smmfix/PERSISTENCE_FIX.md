# Render persistence fix

The server store now uses the Firebase Admin SDK as the persistent source of truth when Firebase Admin credentials are configured. Render's local filesystem (`smm_store_data.json`) is treated only as a cache/fallback, not the primary database.

Required Render environment variables:
- FIREBASE_PROJECT_ID
- FIREBASE_CLIENT_EMAIL
- FIREBASE_PRIVATE_KEY (keep `\\n` sequences if entered as one line)
- FIREBASE_DATABASE_URL

After setting/updating these variables, redeploy/restart the Render service.

This specifically prevents admin margin/settings/services/orders from reverting to the bundled default JSON after a Render restart or redeploy.
